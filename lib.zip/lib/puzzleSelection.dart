// import 'package:flutter/material.dart';

// class PuzzleSelectionScreen extends StatelessWidget {
//   final String title;
//   final String url;

//   // Constructor to accept the title and url
//   PuzzleSelectionScreen({required this.title, required this.url});

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Center(
//         child: Column(
//           children: [
//             Text('Puzzle URL: $url'),  // Display the URL or use it in any widget
//             Text('Puzzle Tittle: $title')
//             // You can replace this with any widget that will use the 'url'
//           ],
//         ),
//       ),
//     );
//   }
// }
